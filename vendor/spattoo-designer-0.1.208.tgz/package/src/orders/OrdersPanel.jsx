import { useState, useEffect, useRef, useCallback, Fragment } from 'react';
import { dietTone, hasAllergen } from './dietary.js';
import {
  buildStatusIndex, DEFAULT_STATUS_INDEX,
  statusLabel, isClosed, isTerminal, isDesignLocked, statusTone,
} from './statuses.js';
import OrdersCalendar from './OrdersCalendar.jsx';
import XrayReport from './xray/XrayReport.jsx';
import { hasXraySpec, resolveXraySpec } from './xray/resolveXraySpec.js';
import { creditsChanged } from '../billing/creditsBus.js';
import PhotoSheet from './PhotoSheet.jsx';
import { compressImage, imageExt, validateImageFile, ACCEPT_IMAGE } from '../shared/image.js';
import { useUploadLimits } from '../shared/useUploadLimits.js';

// Max finished-cake photos the baker may attach when marking an order ready (mirrors the API cap).
const MAX_FINISHED_PHOTOS = 3;

const PhotoGlyph = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinejoin="round" strokeLinecap="round">
    <rect x="3" y="5" width="18" height="14" rx="2" /><circle cx="8.5" cy="10" r="1.6" /><path d="M21 16l-5-5-6 6" />
  </svg>
);

// How many customer-uploaded photo frames the order carries.
function photoFrameCount(order) {
  return (order?.design_snapshot?.stickers ?? []).filter(s => s?.photoMask && s?.photoUrl).length;
}

// Order-detail section: surfaces the customer's uploaded photos and opens the A4 page simulator.
function CustomPhotosSection({ order }) {
  const [open, setOpen] = useState(false);
  const n = photoFrameCount(order);
  if (!n) return null;
  return (
    <div style={{ border: '1.5px solid #cfe0d4', background: '#F1F8F3', borderRadius: 14, padding: '16px 18px', marginBottom: 22 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8, color: '#2C4433' }}>
        <PhotoGlyph />
        <span style={{ fontSize: 12, fontWeight: 800, letterSpacing: 0.6, textTransform: 'uppercase' }}>Custom photos</span>
      </div>
      <div style={{ fontSize: 13, color: '#3D5A44', lineHeight: 1.6, marginBottom: 12 }}>
        The customer uploaded <b>{n}</b> custom photo{n > 1 ? 's' : ''} for this cake. Open the
        A4 page simulator to size and arrange {n > 1 ? 'them' : 'it'} on a sheet, then download a
        print-ready PDF for your edible printer.
      </div>
      <button onClick={() => setOpen(true)}
        style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '10px 18px', borderRadius: 10, border: 'none', background: '#3D5A44', color: '#fff', fontSize: 13, fontWeight: 700, cursor: 'pointer' }}>
        <PhotoGlyph /> Open A4 simulator
      </button>
      {open && <PhotoSheet order={order} onClose={() => setOpen(false)} />}
    </div>
  );
}

// Report/document — the X-Ray panel is a build breakdown the baker reads
// (mixing tables, nozzle recs, tin helper), so a report reads truer than a magnifier.
const XrayGlyph = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M6 2.6h7.5L19 8v12a1.4 1.4 0 0 1-1.4 1.4H6A1.4 1.4 0 0 1 4.6 20V4A1.4 1.4 0 0 1 6 2.6Z" />
    <path d="M13 2.8V8.4h5.6" />
    <line x1="8" y1="13" x2="15" y2="13" /><line x1="8" y1="16.5" x2="13.5" y2="16.5" />
  </svg>
);
const Cube3D = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" strokeLinecap="round">
    <path d="M12 2.6 L20.5 7 L20.5 17 L12 21.4 L3.5 17 L3.5 7 Z" /><path d="M3.5 7 L12 11.5 L20.5 7" /><path d="M12 11.5 L12 21.4" />
  </svg>
);
const LockGlyph = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <rect x="5" y="11" width="14" height="9" rx="2" /><path d="M8 11 V8 a4 4 0 0 1 8 0 V11" />
  </svg>
);
const PencilGlyph = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 20h9" /><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z" />
  </svg>
);

// Icon + label control — white, light border, grey icon + text. No colour fill.
// `variant='row'` (default) = icon + label inline (desktop, below the cake).
// `variant='stack'` = compact column, icon over a small caption (`short`) for the
// mobile side-strip. Full `label` stays as title + aria-label for accessibility.
function IconAction({ glyph, label, short, onClick, disabled, variant = 'row' }) {
  const stack = variant === 'stack';
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      title={label}
      aria-label={label}
      style={{
        display: 'inline-flex', flexDirection: stack ? 'column' : 'row',
        alignItems: 'center', justifyContent: 'center',
        gap: stack ? 3 : 7,
        padding: stack ? '2px' : '9px 16px',
        width: stack ? undefined : undefined,
        borderRadius: stack ? 0 : 10,
        border: stack ? 'none' : '1.5px solid #E0DDD8',
        background: stack ? 'transparent' : '#fff',
        fontSize: stack ? 10.5 : 13, fontWeight: 700, color: '#444', fontFamily: 'inherit',
        lineHeight: 1.2, cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.5 : 1, whiteSpace: 'nowrap',
      }}
    >
      {glyph}<span>{stack ? (short ?? label) : label}</span>
    </button>
  );
}

// X-Ray launcher — an icon+label action that opens the report.
//
// "Is there a design to report on" is resolveXraySpec.js's question, not this component's: a manual
// order can have no design_snapshot and still have a reading of its reference photo. Asking it
// here in a second way is how the launcher and the report end up disagreeing about whether the
// button should exist.
function XrayLauncher({ order, apiClient, variant, enabled }) {
  const [open, setOpen] = useState(false);
  const { design, fromPhoto } = resolveXraySpec(order);
  if (!design) return null;
  // Two different things are being gated, and only one is a plan feature.
  //
  // A DESIGNED order's X-Ray costs us nothing to produce, so it stays what it has always been:
  // a Blaze+ hook (xray_reports). A PHOTO order's was PAID FOR with credits, on any plan — gating
  // it again would take a baker's credits and then withhold what they bought, which is the worst
  // thing this feature could do.
  if (!fromPhoto && !enabled) return null;
  return (
    <>
      <IconAction glyph={<XrayGlyph />} label="X-Ray report" short="X-Ray" onClick={() => setOpen(true)} variant={variant} />
      {open && <XrayReport order={order} apiClient={apiClient} onClose={() => setOpen(false)} />}
    </>
  );
}

// Build-guide-from-a-photo launcher — the entry point for orders that never touched the designer.
//
// Only ever appears where X-Ray CANNOT: a manual order with reference photos, no design_snapshot,
// and no estimate yet. Once an estimate exists the order has a design as far as resolveXraySpec.js
// is concerned, XrayLauncher takes over, and this disappears — so the two are never both offered
// and the baker is never asked to choose between them.
//
// The result is opened directly rather than refetching the order. The route returns the estimate
// it just wrote, so a round trip would re-read what we are already holding, and the panel picks it
// up from the server on its next load anyway.
function PhotoXrayLauncher({ order, apiClient, variant }) {
  const [busy, setBusy] = useState(false);
  const [err, setErr]   = useState(null);
  const [spec, setSpec] = useState(null);

  // NOT gated on xray_reports. Reading a photo costs real money and is metered by CREDITS, which
  // every plan has — so every plan can buy one. Gating it on the Blaze entitlement as well was
  // what left a Flame baker holding an allowance they could not spend on anything.
  const { stale } = resolveXraySpec(order);
  if (!apiClient?.createXraySpec) return null;    // host hasn't wired it → no dead button
  if (order?.design_snapshot) return null;        // designed: X-Ray reads it directly
  // Normally this disappears once a guide exists and XrayLauncher takes over. The exception is a
  // STALE one: the baker has replaced the reference photo, so the cached X-Ray describes a picture
  // that is no longer on the order. It comes back as a re-read, priced and worded as one.
  if (hasXraySpec(order) && !stale) return null;

  async function generate() {
    if (busy) return;
    setBusy(true); setErr(null);
    try {
      // A stale re-read must REGENERATE — without this the route would hand back the very
      // cached X-Ray we are trying to replace, free and unchanged.
      const res = await apiClient.createXraySpec(order.id, { regenerate: stale });
      if (!res?.estimate) throw new Error('No X-Ray came back.');
      setSpec({ spec: res.estimate, meta: res.meta ?? null });
      // Tell the header pill the balance moved. Fired on `reused` too: that call spends nothing,
      // but re-reading is cheap and a pill that is occasionally over-eager is far better than one
      // that is occasionally wrong.
    } catch (e) {
      // Out of credits is an ordinary outcome with its own message, not a failure to apologise
      // for — the baker needs to know the difference between "we could not read your photo" and
      // "you have used this month's allowance".
      // The 402 body carries canTopUp and resetsOn, so the server decides which sentence a baker
      // gets rather than the client guessing from a plan name it does not have. A Flame baker is
      // told when the credits come back and what Blaze changes; a Blaze baker is pointed at a
      // top-up. Saying "or you can top up" to someone who cannot is the worse of the two errors.
      const out = e?.code === 'INSUFFICIENT_CREDITS' || /credit/i.test(e?.message ?? '');
      const on  = e?.resetsOn ? new Date(e.resetsOn).toLocaleDateString('en-IN', { day: 'numeric', month: 'long' }) : null;
      setErr(!out ? (e?.message || 'Could not read that photo.')
        : e?.canTopUp === false
          ? `You've used this month's credits. They refresh${on ? ` on ${on}` : ' next month'}. Blaze adds top-ups, so you never have to wait.`
          : `You've used this month's credits. They refresh${on ? ` on ${on}` : ' next month'} — or top up in Billing.`);
    } finally {
      setBusy(false);
      creditsChanged();   // success, discard or refusal — the header should reflect reality either way
    }
  }

  return (
    <>
      <IconAction
        glyph={<XrayGlyph />}
        label={busy ? 'Reading photo…' : stale ? 'Photo changed — read again' : 'Build guide from photo'}
        short={busy ? 'Reading…' : stale ? 'Re-read' : 'Build guide'}
        onClick={generate}
        disabled={busy}
        variant={variant}
      />
      {err && <span style={{ fontSize: 12, fontWeight: 700, color: '#B00020', maxWidth: 220 }}>{err}</span>}
      {spec && (
        <XrayReport
          // The order as it now is on the server. Merged rather than refetched — same data, one
          // fewer round trip — and resolveXraySpec picks the estimate up from exactly these two
          // fields, so the report cannot tell the difference.
          order={{ ...order, xray_spec: spec.spec, xray_spec_meta: spec.meta }}
          apiClient={apiClient}
          onClose={() => setSpec(null)}
        />
      )}
    </>
  );
}

function useIsMobile() {
  const [mobile, setMobile] = useState(() => window.innerWidth < 768);
  useEffect(() => {
    const fn = () => setMobile(window.innerWidth < 768);
    window.addEventListener('resize', fn);
    return () => window.removeEventListener('resize', fn);
  }, []);
  return mobile;
}

const TIER_LABELS = ['Bottom Tier', '2nd Tier', '3rd Tier', 'Top Tier'];

// ── Order status lifecycle ────────────────────────────────────────────────────
// Readable labels for audit-log event types (else falls back to 'Order edited').
const AUDIT_EVENT_LABELS = {
  status_changed:  'Status changed',
  design_updated:  'Design updated',
  quoted:          'Quote sent',
  quote_approved:  'Quote approved',
  quote_accepted:  'Quote approved',
  customer_message: 'Customer message',
  edited:          'Order edited',
};

function StatusBadge({ status, statusIndex = DEFAULT_STATUS_INDEX }) {
  const t = statusTone(statusIndex, status);
  return (
    <span style={{
      padding: '3px 10px', borderRadius: 20, fontSize: 11, fontWeight: 700,
      letterSpacing: 0.3, background: t.bg, color: t.color,
      border: `1px solid ${t.border}`, whiteSpace: 'nowrap',
    }}>{statusLabel(statusIndex, status)}</span>
  );
}

function fmt(iso) {
  if (!iso) return null;
  return new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

// Same rendering as fmt() but for a DATE-only string ('2026-07-04'). Built from the
// parts rather than parsed: `new Date('2026-07-04')` is UTC midnight, which formats as
// the PREVIOUS day for anyone west of Greenwich — a calendar must never be off by one.
function fmtDateOnly(date) {
  if (!date) return null;
  const [y, m, d] = String(date).split('-').map(Number);
  if (!y || !m || !d) return date;
  return new Date(y, m - 1, d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

function InfoRow({ label, value }) {
  if (!value) return null;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      <span style={{ fontSize: 10, fontWeight: 700, color: '#bbb', textTransform: 'uppercase', letterSpacing: 0.8 }}>{label}</span>
      <span style={{ fontSize: 14, color: '#222', lineHeight: 1.5, wordBreak: 'break-word' }}>{value}</span>
    </div>
  );
}

// ── Quote panel ───────────────────────────────────────────────────────────────
// Baker price entry → "Send quote". Visible only while the order is in the quote
// phase (initiated/requested/quoted); once confirmed it shows the agreed price
// read-only. A quote pins to the current design version — if the design changed
// after the quote (stale), the baker can re-affirm the price (re-pin) or set a new
// one. The suggested-price algorithm (plan §2) is not here yet — this is manual entry.
function QuotePanel({ order, statusIndex, onIssue, busy, error, primaryColor = '#1a1a1a', onConfirm, confirming }) {
  const phase = statusIndex.byKey[order.status]?.phase;
  const hasQuote = order.quoted_price != null;
  // Advance defaults to 50% of the price (rounded) and auto-tracks the price field
  // until the baker edits it — then their value sticks. An already-saved advance is
  // respected as-is.
  const halfOf = (p) => {
    const n = parseFloat(p);
    return Number.isFinite(n) && n > 0 ? String(Math.round(n / 2)) : '';
  };
  const [price, setPrice]     = useState(hasQuote ? String(order.quoted_price) : '');
  const [advance, setAdvance] = useState(order.advance_amount != null ? String(order.advance_amount) : halfOf(order.quoted_price));
  const [advanceTouched, setAdvanceTouched] = useState(order.advance_amount != null);
  const [note, setNote]       = useState(order.quote_note ?? '');

  const btn = (bg, color, border) => ({
    padding: '10px 16px', borderRadius: 10, border: border ?? 'none', background: bg,
    color, fontSize: 13, fontWeight: 700, cursor: (busy || confirming) ? 'default' : 'pointer',
    fontFamily: 'inherit', opacity: (busy || confirming) ? 0.6 : 1,
  });

  // Out of the quote phase. quote_approved = customer is happy with the price; the
  // baker confirms (advance received) to lock it in. Confirmed onward = read-only.
  if (phase !== 'quote') {
    if (order.status === 'quote_approved') {
      return (
        <Section title="Quote">
          <InfoRow label="Approved price" value={`₹${order.quoted_price}`} />
          {order.advance_amount != null && <InfoRow label="Advance" value={`₹${order.advance_amount}`} />}
          <div style={{ fontSize: 12.5, color: '#2C4433', background: '#EAF0EC', borderRadius: 10, padding: '8px 12px', lineHeight: 1.5 }}>
            The customer is happy with the price. Confirm the order once you&apos;ve received the advance.
          </div>
          <button disabled={confirming} onClick={onConfirm} style={btn(primaryColor, '#fff')}>
            {confirming ? 'Confirming…' : 'Confirm order'}
          </button>
        </Section>
      );
    }
    if (!hasQuote) return null;
    return (
      <Section title="Quote">
        <InfoRow label="Agreed price" value={`₹${order.quoted_price}`} />
        {order.advance_amount != null && <InfoRow label="Advance" value={`₹${order.advance_amount}`} />}
      </Section>
    );
  }

  const stale = !!order.quote_stale;
  const label = busy ? 'Sending…' : hasQuote ? (stale ? 'Re-send quote' : 'Update quote') : 'Send quote';
  const inputStyle = { width: '100%', padding: '10px 12px', borderRadius: 10, border: '1.5px solid #E0DDD8', fontSize: 14, fontFamily: 'inherit', color: '#222', outline: 'none', boxSizing: 'border-box' };
  const issue = (p, a) => onIssue({ price: p, advanceAmount: a === '' || a == null ? null : parseFloat(a), note });

  return (
    <Section title="Quote">
      {hasQuote && (
        <InfoRow label="Current quote" value={`₹${order.quoted_price}${stale ? ' · design changed' : ''}`} />
      )}
      {stale && (
        <div style={{ fontSize: 12.5, color: '#7a5b00', background: '#FEF9C3', border: '1px solid #FCD34D', borderRadius: 10, padding: '8px 12px', lineHeight: 1.5 }}>
          The design changed since this quote. Re-affirm the price (re-pins it to the new design) or set a new one.
        </div>
      )}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ fontSize: 15, fontWeight: 700, color: '#555' }}>₹</span>
        <input value={price} onChange={e => { setPrice(e.target.value); if (!advanceTouched) setAdvance(halfOf(e.target.value)); }} inputMode="decimal" placeholder="Price" style={{ ...inputStyle, flex: 1, minWidth: 0 }} />
      </div>
      <input value={advance} onChange={e => { setAdvance(e.target.value); setAdvanceTouched(true); }} inputMode="decimal" placeholder="Advance to confirm (50% by default)" style={inputStyle} />
      <textarea value={note} onChange={e => setNote(e.target.value)} rows={2} placeholder="A note to the customer (optional) — e.g. love this design, can't wait to bake it!" style={{ ...inputStyle, resize: 'vertical' }} />
      <div style={{ display: 'flex', gap: 8 }}>
        <button disabled={busy} onClick={() => issue(parseFloat(price), advance)} style={btn(primaryColor, '#fff')}>{label}</button>
        {stale && hasQuote && (
          <button disabled={busy} onClick={() => issue(order.quoted_price, order.advance_amount)} style={btn('#fff', '#333', '1.5px solid #E0DDD8')}>Price holds</button>
        )}
      </div>
      {error && <div style={{ fontSize: 12.5, fontWeight: 700, color: '#C0392B' }}>{error}</div>}
    </Section>
  );
}

// The baker's forward action(s) from the current status, as prominent buttons (so
// they don't have to hunt the timeline dots). Quote-phase actions (Send quote /
// Confirm order) live in QuotePanel; this covers fulfillment. 'in_production' is an
// internal, OPTIONAL step (no customer/baker email) — from 'confirmed' the baker can
// start production OR jump straight to ready. First action = primary, the rest = a
// lighter "skip ahead" button. Terminal/closed/quote states → nothing.
const NEXT_ACTIONS = {
  confirmed:     [{ to: 'in_production', label: 'Start production' }, { to: 'ready', label: 'Mark as ready' }],
  in_production: [{ to: 'ready', label: 'Mark as ready' }],
  ready:         [{ to: 'completed', label: 'Mark as completed' }],
};
function NextStatusAction({ order, statusIndex, onAdvance, busy, primaryColor = '#1a1a1a' }) {
  const actions = (NEXT_ACTIONS[order.status] ?? []).filter(a => statusIndex.byKey[a.to]);
  if (!actions.length) return null;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 20 }}>
      {actions.map((a, i) => {
        const primary = i === 0;
        return (
          <button
            key={a.to}
            disabled={busy}
            onClick={() => onAdvance(a.to)}
            style={{
              width: '100%', padding: '12px', borderRadius: 11,
              border: primary ? 'none' : '1.5px solid #E0DDD8',
              background: primary ? (busy ? '#9BB5A2' : primaryColor) : '#fff',
              color: primary ? '#fff' : '#333',
              fontSize: 14, fontWeight: 800, cursor: busy ? 'default' : 'pointer', fontFamily: 'inherit',
            }}
          >
            {busy ? 'Updating…' : a.label}
          </button>
        );
      })}
    </div>
  );
}

// ── Mark-ready: finished-cake photos ──────────────────────────────────────────
// When the baker marks an order 'ready' we let them OPTIONALLY attach up to 3 photos
// of the finished cake. They ride along in the order-ready email, so they must be
// uploaded + persisted BEFORE the status flips (the email fires synchronously on the
// transition). This sheet uploads each pick to R2 (orders/photos) as it's added and
// hands the resulting keys back on confirm; the caller persists them then advances.
// Photos are never required — "Mark as ready" works with zero.
function MarkReadySheet({ order, apiClient, primaryColor = '#1a1a1a', busy, error, onConfirm, onCancel }) {
  const [photos, setPhotos] = useState([]);   // { id, previewUrl, key|null, uploading, failed }
  const [pickError, setPickError] = useState(null);   // why a chosen file was refused
  const { maxImageBytes } = useUploadLimits(apiClient);   // the server's ceiling, not a copy of it
  const uploading = photos.some(p => p.uploading);
  const atMax = photos.length >= MAX_FINISHED_PHOTOS;

  // Revoke any still-live object URLs on unmount (a ref tracks the latest set, since the
  // cleanup runs once and would otherwise close over the initial empty array).
  const photosRef = useRef(photos);
  photosRef.current = photos;
  useEffect(() => () => photosRef.current.forEach(p => p.previewUrl && URL.revokeObjectURL(p.previewUrl)), []);

  async function addFiles(e) {
    const files = [...(e.target.files || [])].slice(0, MAX_FINISHED_PHOTOS - photos.length);
    e.target.value = '';
    setPickError(null);
    for (const file of files) {
      // Refuse what we cannot use, WITH a reason. A HEIC (a Mac drag-drop, an untranscoded iPhone
      // share) satisfies `image/*`, so it used to get this far, fail to decode, fall through as the
      // original file and then be refused by the API's content-type allowlist — surfacing to the
      // baker as a photo that just says "failed" with nothing to act on.
      const bad = validateImageFile(file, { maxBytes: maxImageBytes });
      if (bad) { setPickError(bad); continue; }
      const id = `p${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      const previewUrl = URL.createObjectURL(file);
      setPhotos(ps => [...ps, { id, previewUrl, key: null, uploading: true, failed: false }]);
      try {
        const blob = await compressImage(file);
        const ct = blob.type || file.type || 'image/jpeg';
        const filename = `${order.id}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}.${imageExt(blob)}`;
        const { url, key } = await apiClient.getSignedUploadUrl('orders/photos', filename, ct, blob.size);
        await fetch(url, { method: 'PUT', headers: { 'Content-Type': ct }, body: blob });
        setPhotos(ps => ps.map(p => (p.id === id ? { ...p, key, uploading: false } : p)));
      } catch (err) {
        console.error('Finished-photo upload failed', err);
        setPhotos(ps => ps.map(p => (p.id === id ? { ...p, uploading: false, failed: true } : p)));
      }
    }
  }

  function remove(id) {
    setPhotos(ps => {
      const it = ps.find(p => p.id === id);
      if (it?.previewUrl) URL.revokeObjectURL(it.previewUrl);
      return ps.filter(p => p.id !== id);
    });
  }

  const slots = [...photos];
  if (!atMax) slots.push(null);   // trailing "add" tile

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 1000, background: 'rgba(20,18,16,0.55)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16,
    }} onClick={busy ? undefined : onCancel}>
      <div onClick={e => e.stopPropagation()} style={{
        width: '100%', maxWidth: 440, background: '#fff', borderRadius: 18, padding: 22,
        boxShadow: '0 18px 50px rgba(0,0,0,0.3)', fontFamily: 'inherit',
      }}>
        <h3 style={{ margin: '0 0 4px', fontSize: 18, fontWeight: 800, color: '#1a1a1a' }}>Mark as ready</h3>
        <p style={{ margin: '0 0 16px', fontSize: 13.5, color: '#777', lineHeight: 1.5 }}>
          Add a few photos of the finished cake — your customer will see them in their "order ready" email.
          <b> Optional</b>; you can mark ready without any.
        </p>

        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 18 }}>
          {slots.map((p, i) => p ? (
            <div key={p.id} style={{ position: 'relative', width: 96, height: 96 }}>
              <img src={p.previewUrl} alt="Finished cake" style={{
                width: 96, height: 96, objectFit: 'cover', borderRadius: 12,
                border: '1.5px solid #E8E4DC', opacity: p.uploading ? 0.55 : 1,
                filter: p.failed ? 'grayscale(1)' : 'none',
              }} />
              {p.uploading && <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, color: '#444' }}>Uploading…</div>}
              {p.failed && <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, color: '#c0392b' }}>Failed</div>}
              {!busy && (
                <button onClick={() => remove(p.id)} aria-label="Remove photo" style={{
                  position: 'absolute', top: -8, right: -8, width: 22, height: 22, borderRadius: '50%',
                  border: 'none', background: '#1a1a1a', color: '#fff', fontSize: 13, fontWeight: 700,
                  cursor: 'pointer', lineHeight: '22px', textAlign: 'center', padding: 0,
                }}>×</button>
              )}
            </div>
          ) : (
            <label key="add" style={{
              width: 96, height: 96, borderRadius: 12, border: '1.5px dashed #C9C4BC',
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
              gap: 4, cursor: busy ? 'default' : 'pointer', color: '#999', background: '#FAF9F6',
            }}>
              <PhotoGlyph />
              <span style={{ fontSize: 11, fontWeight: 700 }}>Add photo</span>
              {/* No `capture` attr: on phones this lets the baker choose Camera OR gallery; on
                  desktop (browser fallback) it's a plain file picker. */}
              <input type="file" accept={ACCEPT_IMAGE} multiple disabled={busy}
                onChange={addFiles} style={{ display: 'none' }} />
            </label>
          ))}
        </div>

        {pickError && <p style={{ color: '#c0392b', fontSize: 13, margin: '0 0 12px' }}>{pickError}</p>}
        {error && <p style={{ color: '#c0392b', fontSize: 13, margin: '0 0 12px' }}>{error}</p>}

        <div style={{ display: 'flex', gap: 10 }}>
          <button onClick={onCancel} disabled={busy} style={{
            flex: '0 0 auto', padding: '12px 18px', borderRadius: 11, border: '1.5px solid #E0DDD8',
            background: '#fff', color: '#555', fontSize: 14, fontWeight: 700, cursor: busy ? 'default' : 'pointer', fontFamily: 'inherit',
          }}>Cancel</button>
          <button
            onClick={() => onConfirm(photos.filter(p => p.key).map(p => p.key))}
            disabled={busy || uploading}
            style={{
              flex: 1, padding: '12px', borderRadius: 11, border: 'none',
              background: (busy || uploading) ? '#9BB5A2' : primaryColor, color: '#fff',
              fontSize: 14, fontWeight: 800, cursor: (busy || uploading) ? 'default' : 'pointer', fontFamily: 'inherit',
            }}>
            {busy ? 'Marking ready…' : uploading ? 'Uploading…' : 'Mark as ready'}
          </button>
        </div>
      </div>
    </div>
  );
}

// Read-only strip of the finished-cake photos on a ready/completed order.
// One gallery renders any order photo SET (finished-cake or reference) — same fetch +
// grid, only the title and the loader differ. Hidden when the set is empty.
function OrderPhotoGallery({ title, orderId, load, refresh }) {
  const [photos, setPhotos] = useState([]);
  useEffect(() => {
    if (!load) return;
    let live = true;
    load(orderId)
      .then(d => { if (live && Array.isArray(d)) setPhotos(d); })
      .catch(() => {});
    return () => { live = false; };
  }, [orderId, refresh, load]);
  if (!photos.length) return null;
  return (
    <Section title={title}>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        {photos.map(p => (
          <img key={p.id} src={p.url} alt={title} style={{
            width: 96, height: 96, objectFit: 'cover', borderRadius: 10, border: '1.5px solid #E8E4DC',
          }} />
        ))}
      </div>
    </Section>
  );
}

function FinishedPhotosSection({ order, apiClient, refresh }) {
  return <OrderPhotoGallery title="Finished cake photos" orderId={order.id} load={apiClient?.fetchOrderPhotos} refresh={refresh} />;
}

// Reference photos the baker took from the customer for a manual (no-design) order.
// Only design-less orders have them — a designed order shows its 3D preview instead.
function ReferencePhotosSection({ order, apiClient }) {
  if (order.design_snapshot) return null;
  return <OrderPhotoGallery title="Reference photos" orderId={order.id} load={apiClient?.fetchOrderReferencePhotos} />;
}

// ── Edit form ─────────────────────────────────────────────────────────────────

// Normalise an order's stored flavours into editable rows. Entries may come back
// as { name | flavour, flavourId | flavour_id, tier, source }.
function normaliseFlavours(order) {
  const rows = (order.flavours ?? []).map((f, i) => ({
    tier:      f.tier ?? i,
    name:      f.name ?? f.flavour ?? '',
    flavourId: f.flavourId ?? f.flavour_id ?? null,
    source:    f.source ?? null,
  }));
  return rows.length ? rows : [{ tier: 0, name: '', flavourId: null, source: null }];
}

function EditForm({ order, onSave, onCancel, saving, serverError, homeDeliveryEnabled = false, availableFlavours = [] }) {
  const [form, setForm] = useState({
    weight_kg:            order.weight_kg ?? '',
    delivery_date:        order.delivery_date ?? '',
    delivery_time:        order.delivery_time ?? '',
    delivery_mode:        (!homeDeliveryEnabled && order.delivery_mode === 'home_delivery') ? 'pickup' : (order.delivery_mode ?? 'pickup'),
    delivery_address:     order.delivery_address ?? '',
    special_instructions: order.special_instructions ?? '',
    flavours:             normaliseFlavours(order),
    comment:              '',
  });
  const [errors, setErrors] = useState({});

  function set(k, v) { setForm(f => ({ ...f, [k]: v })); setErrors(e => ({ ...e, [k]: null })); }

  function setFlavour(tierIdx, flavourId) {
    const picked = availableFlavours.find(f => f.id === flavourId) ?? null;
    setForm(f => ({
      ...f,
      flavours: f.flavours.map((row, i) => i === tierIdx
        ? { ...row, name: picked?.name ?? '', flavourId: picked?.id ?? null, source: picked?.source ?? null }
        : row),
    }));
  }

  function setFlavourName(tierIdx, name) {
    setForm(f => ({
      ...f,
      flavours: f.flavours.map((row, i) => i === tierIdx
        ? { ...row, name, flavourId: null, source: null }
        : row),
    }));
  }

  const multiTier = form.flavours.length > 1;

  function validate() {
    const e = {};
    if (form.delivery_mode === 'home_delivery' && !form.delivery_address.trim())
      e.delivery_address = 'Address is required for home delivery';
    if (!form.comment.trim())
      e.comment = 'Please add a comment explaining the change';
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function handleSave() {
    if (validate()) onSave(form);
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <div style={{ display: 'flex', gap: 12 }}>
        <Field label="Weight (kg)">
          <input style={inp} type="number" min="0.5" step="0.5"
            value={form.weight_kg} onChange={e => set('weight_kg', e.target.value)} />
        </Field>
      </div>

      <Field label={multiTier ? 'Flavour per tier' : 'Flavour'}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {form.flavours.map((row, i) => (
            <div key={i} style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
              {multiTier && (
                <span style={{ fontSize: 10, fontWeight: 700, color: '#bbb' }}>
                  {TIER_LABELS[i] ?? `Tier ${i + 1}`}
                </span>
              )}
              {availableFlavours.length > 0 ? (
                <select
                  style={{ ...inp, appearance: 'none', WebkitAppearance: 'none', cursor: 'pointer' }}
                  value={row.flavourId ?? ''}
                  onChange={e => setFlavour(i, e.target.value || null)}
                >
                  <option value="">— Select flavour —</option>
                  {/* Keep a free-text legacy flavour selectable even if not in the list */}
                  {row.name && !row.flavourId && !availableFlavours.some(f => f.name === row.name) && (
                    <option value="">{row.name}</option>
                  )}
                  {availableFlavours.map(f => (
                    <option key={f.id} value={f.id}>{f.name}</option>
                  ))}
                </select>
              ) : (
                <input style={inp} placeholder="e.g. Vanilla"
                  value={row.name}
                  onChange={e => setFlavourName(i, e.target.value)} />
              )}
            </div>
          ))}
        </div>
      </Field>

      <div style={{ display: 'flex', gap: 12 }}>
        <Field label="Delivery date">
          <input style={inp} type="date" value={form.delivery_date} onChange={e => set('delivery_date', e.target.value)} />
        </Field>
        <Field label="Time">
          <input style={inp} type="time" value={form.delivery_time} onChange={e => set('delivery_time', e.target.value)} />
        </Field>
      </div>

      <Field label="Delivery mode">
        <div style={{ display: 'flex', gap: 8 }}>
          {[['pickup', 'Pickup'], ['home_delivery', 'Home Delivery']].map(([val, label]) => {
            const disabled = val === 'home_delivery' && !homeDeliveryEnabled;
            if (disabled) return null;
            const active = form.delivery_mode === val;
            return (
              <button key={val} onClick={() => set('delivery_mode', val)} style={{
                flex: 1, padding: '9px', borderRadius: 10, cursor: 'pointer',
                fontFamily: 'inherit', fontSize: 13, fontWeight: 700,
                border: `1.5px solid ${active ? '#555' : '#E0DDD8'}`,
                background: active ? '#1a1a1a' : '#fff',
                color: active ? '#fff' : '#888',
              }}>{label}</button>
            );
          })}
        </div>
      </Field>

      {form.delivery_mode === 'home_delivery' && (
        <Field label="Address *" error={errors.delivery_address}>
          <textarea
            style={{ ...inp, minHeight: 72, resize: 'vertical', borderColor: errors.delivery_address ? '#e53935' : inp.borderColor }}
            value={form.delivery_address} onChange={e => set('delivery_address', e.target.value)} />
        </Field>
      )}

      <Field label="Special instructions">
        <textarea style={{ ...inp, minHeight: 64, resize: 'vertical' }}
          value={form.special_instructions} onChange={e => set('special_instructions', e.target.value)} />
      </Field>

      <Field label="Comment *" hint="Explain what you changed and why" error={errors.comment}>
        <textarea
          style={{ ...inp, minHeight: 72, resize: 'vertical', borderColor: errors.comment ? '#e53935' : '#f59e0b' }}
          placeholder="e.g. Customer called and changed delivery date to Friday"
          value={form.comment} onChange={e => set('comment', e.target.value)} />
      </Field>

      {serverError && (
        <div style={{ padding: '10px 14px', borderRadius: 10, background: '#FEE2E2', border: '1px solid #FECACA', fontSize: 13, color: '#991B1B', fontWeight: 600 }}>
          {serverError}
        </div>
      )}

      <div style={{ display: 'flex', gap: 10 }}>
        <button onClick={handleSave} disabled={saving} style={{
          flex: 1, padding: '12px', borderRadius: 12, border: 'none',
          background: '#1a1a1a', color: '#fff', fontSize: 13, fontWeight: 700,
          cursor: saving ? 'not-allowed' : 'pointer', fontFamily: 'inherit',
          opacity: saving ? 0.6 : 1,
        }}>
          {saving ? 'Saving…' : 'Save Changes'}
        </button>
        <button onClick={onCancel} style={{
          padding: '12px 18px', borderRadius: 12, border: '1.5px solid #E0DDD8',
          background: '#fff', color: '#666', fontSize: 13, fontWeight: 700,
          cursor: 'pointer', fontFamily: 'inherit',
        }}>Cancel</button>
      </div>
    </div>
  );
}

function Field({ label, hint, error, children }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 5, flex: 1 }}>
      <span style={{ fontSize: 10, fontWeight: 700, color: error ? '#e53935' : '#aaa', textTransform: 'uppercase', letterSpacing: 0.8 }}>{label}</span>
      {hint && !error && <span style={{ fontSize: 11, color: '#bbb', marginTop: -2 }}>{hint}</span>}
      {error && <span style={{ fontSize: 11, color: '#e53935', fontWeight: 600, marginTop: -2 }}>{error}</span>}
      {children}
    </div>
  );
}

const inp = {
  padding: '9px 12px', borderRadius: 10, border: '1.5px solid #E0DDD8',
  fontSize: 13, fontFamily: 'inherit', color: '#222',
  outline: 'none', width: '100%', boxSizing: 'border-box', background: '#fff',
};

// ── Audit trail ───────────────────────────────────────────────────────────────

// Render an audit value; flavours come through as an array of objects.
function fmtAuditValue(v) {
  if (v == null || v === '') return '—';
  if (Array.isArray(v)) {
    const names = v.map(f => f?.name ?? f?.flavour).filter(Boolean);
    return names.length ? names.join(', ') : '—';
  }
  return String(v);
}

function AuditTrail({ orderId, apiClient, refresh }) {
  const [log, setLog]       = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!apiClient?.fetchOrderAudit) return;
    setLoading(true);
    apiClient.fetchOrderAudit(orderId)
      .then(data => setLog(Array.isArray(data) ? data : []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [orderId, refresh]);

  if (loading) return <div style={{ fontSize: 12, color: '#bbb', padding: '8px 0' }}>Loading history…</div>;
  if (!log.length) return <div style={{ fontSize: 12, color: '#ddd', padding: '8px 0' }}>No changes recorded yet.</div>;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
      {log.map((entry, i) => {
        const isLast = i === log.length - 1;
        const changedFields = entry.changes ? Object.keys(entry.changes) : [];
        return (
          <div key={entry.id} style={{ display: 'flex', gap: 12, position: 'relative' }}>
            {/* Timeline line */}
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flexShrink: 0 }}>
              <div style={{
                width: 10, height: 10, borderRadius: '50%', marginTop: 4,
                background: entry.event === 'status_changed' ? '#6366f1' : entry.event === 'design_updated' ? '#10b981' : '#f59e0b',
                border: '2px solid #fff', boxShadow: '0 0 0 1px #E0DDD8', flexShrink: 0,
              }} />
              {!isLast && <div style={{ width: 2, flex: 1, background: '#F0EDE8', minHeight: 16 }} />}
            </div>

            <div style={{ paddingBottom: isLast ? 0 : 16, flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
                <div>
                  <span style={{ fontSize: 12, fontWeight: 700, color: '#444' }}>
                    {AUDIT_EVENT_LABELS[entry.event] ?? 'Order edited'}
                  </span>
                  {entry.changed_by_name && (
                    <span style={{ fontSize: 11, color: '#aaa', marginLeft: 6 }}>by {entry.changed_by_name}</span>
                  )}
                </div>
                <span style={{ fontSize: 11, color: '#bbb', flexShrink: 0 }}>
                  {new Date(entry.changed_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>

              {changedFields.length > 0 && (
                <div style={{ marginTop: 4, fontSize: 12, color: '#888' }}>
                  {changedFields.map(f => {
                    const { from, to } = entry.changes[f];
                    return (
                      <div key={f} style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                        <span style={{ color: '#bbb' }}>{f.replace(/_/g, ' ')}:</span>
                        <span style={{ textDecoration: 'line-through', color: '#ccc' }}>{fmtAuditValue(from)}</span>
                        <span>→</span>
                        <span style={{ color: '#444', fontWeight: 600 }}>{fmtAuditValue(to)}</span>
                      </div>
                    );
                  })}
                </div>
              )}

              {entry.comment && (
                <div style={{
                  marginTop: 6, fontSize: 12, color: '#555', fontStyle: 'italic',
                  background: '#FAFAF8', border: '1px solid #F0EDE8',
                  borderRadius: 8, padding: '6px 10px',
                }}>
                  "{entry.comment}"
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ── Detail pane ───────────────────────────────────────────────────────────────

function OrderDetail({ order, onEditDesign, onStatusChange, onOrderEdited, apiClient, primaryColor, isMobile, homeDeliveryEnabled = false, bakerSlug = null, statusIndex = DEFAULT_STATUS_INDEX }) {
  const [changingStatus, setChangingStatus] = useState(false);
  const [editing, setEditing]               = useState(false);
  const [saving, setSaving]                 = useState(false);
  const [auditRefresh, setAuditRefresh]     = useState(0);
  const [availableFlavours, setAvailableFlavours] = useState([]);
  const [xrayEnabled, setXrayEnabled] = useState(false);   // X-Ray report is a Blaze+ entitlement

  useEffect(() => {
    if (!bakerSlug || !apiClient?.fetchFlavours) return;
    apiClient.fetchFlavours(bakerSlug)
      .then(data => { if (Array.isArray(data)) setAvailableFlavours(data); })
      .catch(() => {});
  }, [bakerSlug]);

  useEffect(() => {
    if (!apiClient?.fetchEntitlements) return;
    apiClient.fetchEntitlements()
      .then(res => setXrayEnabled(res?.ent?.xray_reports === true))
      .catch(() => {});
  }, []);

  const customer  = order.customers;
  const name      = customer ? `${customer.first_name ?? ''} ${customer.last_name ?? ''}`.trim() : 'Unknown';
  const flavours  = (order.flavours ?? []).map(f => f.name ?? f.flavour).filter(Boolean);
  const delivDate = fmt(order.delivery_date);

  async function handleStatus(s) {
    if (s === order.status || changingStatus) return;
    setChangingStatus(true);
    await onStatusChange(order.id, s);
    setAuditRefresh(r => r + 1);
    setChangingStatus(false);
  }

  // Marking 'ready' opens the finished-photos sheet first (when the host supports
  // uploads) so the optional photos are persisted BEFORE the email-firing transition.
  // Every other transition advances directly.
  const [markingReady, setMarkingReady] = useState(false);
  const [readyErr, setReadyErr]         = useState(null);
  const canAttachPhotos = !!(apiClient?.getSignedUploadUrl && apiClient?.saveOrderPhotos);

  function advance(s) {
    if (s === 'ready' && canAttachPhotos && order.status !== 'ready') {
      setReadyErr(null);
      setMarkingReady(true);
      return;
    }
    handleStatus(s);
  }

  async function confirmMarkReady(keys) {
    if (changingStatus) return;
    setChangingStatus(true);
    setReadyErr(null);
    try {
      if (keys.length) await apiClient.saveOrderPhotos(order.id, keys);   // persist BEFORE the email fires
      await onStatusChange(order.id, 'ready');
      setAuditRefresh(r => r + 1);
      setMarkingReady(false);
    } catch (err) {
      setReadyErr(err.message || 'Could not mark ready');
    } finally {
      setChangingStatus(false);
    }
  }

  const [quoting, setQuoting]   = useState(false);
  const [quoteErr, setQuoteErr] = useState(null);

  // Issue (or re-issue) the quote: captures the price and pins it to the current
  // design version. Re-issuing with the existing price on a stale quote = "price
  // holds". Sent by the QuotePanel below.
  async function handleIssueQuote({ price, advanceAmount, note }) {
    if (!(price > 0)) { setQuoteErr('Enter a valid price'); return; }
    if (advanceAmount != null && advanceAmount > price) { setQuoteErr('Advance cannot exceed the price'); return; }
    if (quoting) return;
    setQuoting(true); setQuoteErr(null);
    try {
      const updated = await apiClient.issueQuote(order.id, { price, advanceAmount, note });
      onOrderEdited({ ...order, ...updated });
      setAuditRefresh(r => r + 1);
    } catch (err) {
      setQuoteErr(err.message);
    } finally {
      setQuoting(false);
    }
  }

  const [saveError, setSaveError] = useState(null);

  async function handleSaveEdit(formData) {
    setSaving(true);
    setSaveError(null);
    try {
      const updated = await apiClient.editOrder(order.id, formData);
      onOrderEdited({ ...order, ...updated });
      setEditing(false);
      setAuditRefresh(r => r + 1);
    } catch (err) {
      setSaveError(err.message);
    } finally {
      setSaving(false);
    }
  }

  // From 'confirmed' onward (and closed states) the design is pinned: open it VIEW-only
  // in 3D (no edits/save) instead of the editor. Earlier (quote phase) stays editable.
  const designLocked = isDesignLocked(statusIndex, order.status);

  // The three cake-panel actions. 'row' = labeled, horizontal (desktop, below the
  // cake). 'strip' = icon-only, vertical (mobile, beside a compact preview). Same
  // three actions either way — one definition, variant only changes the chrome.
  const renderCakeActions = (layout) => {
    const stack = layout === 'strip';
    const v = stack ? 'stack' : 'row';
    return (
      <div style={{
        display: 'flex',
        flexDirection: stack ? 'column' : 'row',
        gap: stack ? 20 : 12,
        justifyContent: 'center', alignItems: 'center',
        flexWrap: stack ? 'nowrap' : 'wrap',
      }}>
        <XrayLauncher order={order} apiClient={apiClient} variant={v} enabled={xrayEnabled} />
        <PhotoXrayLauncher order={order} apiClient={apiClient} variant={v} />
        <IconAction
          glyph={<Cube3D />}
          label={designLocked ? 'View in 3D' : 'Edit in 3D'}
          short={designLocked ? 'View 3D' : '3D Edit'}
          onClick={() => onEditDesign(order, { viewOnly: designLocked })}
          disabled={!order.design_snapshot}
          variant={v}
        />
        {!editing && <IconAction glyph={<PencilGlyph />} label="Edit Details" short="Edit" onClick={() => setEditing(true)} variant={v} />}
      </div>
    );
  };

  // ── Mobile: stacked layout ────────────────────────────────────────────────
  if (isMobile) {
    return (
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px' }}>
        {/* Snapshot + actions side by side — preview (zoomed to fill), icon strip beside it. */}
        <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 20 }}>
          <div style={{
            flex: 1, minWidth: 0, height: 280, borderRadius: 16, overflow: 'hidden',
            background: '#F0EDE8', border: '1.5px solid #E8E4DC',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            {order.design_thumbnail_url
              ? <img src={order.design_thumbnail_url} alt="Cake design"
                  style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
              : <div style={{ textAlign: 'center', color: '#bbb', fontSize: 13, fontWeight: 600 }}>No preview</div>
            }
          </div>
          {renderCakeActions('strip')}
        </div>
        {editing
          ? <EditForm order={order} onSave={handleSaveEdit} onCancel={() => { setEditing(false); setSaveError(null); }} saving={saving} serverError={saveError} homeDeliveryEnabled={homeDeliveryEnabled} availableFlavours={availableFlavours} />
          : <>
              {/* Action buttons (send quote / confirm / cancel) sit directly below the
                  image; the status flow goes underneath them. */}
              <QuotePanel order={order} statusIndex={statusIndex} onIssue={handleIssueQuote} busy={quoting} error={quoteErr} primaryColor={primaryColor} onConfirm={() => handleStatus('confirmed')} confirming={changingStatus} />
              <NextStatusAction order={order} statusIndex={statusIndex} onAdvance={advance} busy={changingStatus} primaryColor={primaryColor} />
              {!isClosed(statusIndex, order.status) && !isTerminal(statusIndex, order.status) && (
                <div style={{ marginBottom: 20 }}>
                  <CancelOrderLink onClick={() => handleStatus('cancelled')} disabled={changingStatus} />
                </div>
              )}
              <StatusProgress status={order.status} onChange={advance} disabled={changingStatus} statusIndex={statusIndex} hideCancel />
              <CustomPhotosSection order={order} />
              <ReferencePhotosSection order={order} apiClient={apiClient} />
              <FinishedPhotosSection order={order} apiClient={apiClient} refresh={auditRefresh} />
              <DetailSections order={order} name={name} flavours={flavours} delivDate={delivDate} />
              <Section title="History">
                <AuditTrail orderId={order.id} apiClient={apiClient} refresh={auditRefresh} />
              </Section>
            </>
        }
        {markingReady && (
          <MarkReadySheet order={order} apiClient={apiClient} primaryColor={primaryColor}
            busy={changingStatus} error={readyErr}
            onConfirm={confirmMarkReady} onCancel={() => { if (!changingStatus) setMarkingReady(false); }} />
        )}
      </div>
    );
  }

  // ── Desktop: side-by-side layout ──────────────────────────────────────────
  return (
    <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>

      {/* Left: cake image + edit */}
      <div style={{
        width: '42%', flexShrink: 0, background: '#F0EDE8',
        display: 'flex', flexDirection: 'column',
        borderRight: '1.5px solid #E8E4DC', padding: 24, gap: 20,
      }}>
        <div style={{
          flex: 1, borderRadius: 20, overflow: 'hidden',
          background: '#fff', border: '1.5px solid #E8E4DC',
          display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 0,
        }}>
          {order.design_thumbnail_url
            ? <img src={order.design_thumbnail_url} alt="Cake design"
                style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
            : <div style={{ textAlign: 'center', color: '#bbb', fontSize: 13, fontWeight: 600 }}>No preview</div>
          }
        </div>
        {renderCakeActions('row')}
      </div>

      {/* Right: details */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '28px' }}>
        {editing
          ? <EditForm order={order} onSave={handleSaveEdit} onCancel={() => { setEditing(false); setSaveError(null); }} saving={saving} serverError={saveError} homeDeliveryEnabled={homeDeliveryEnabled} availableFlavours={availableFlavours} />
          : <>
              <CustomPhotosSection order={order} />
              <ReferencePhotosSection order={order} apiClient={apiClient} />
              <FinishedPhotosSection order={order} apiClient={apiClient} refresh={auditRefresh} />
              <StatusProgress status={order.status} onChange={advance} disabled={changingStatus} statusIndex={statusIndex} />
              <QuotePanel order={order} statusIndex={statusIndex} onIssue={handleIssueQuote} busy={quoting} error={quoteErr} primaryColor={primaryColor} onConfirm={() => handleStatus('confirmed')} confirming={changingStatus} />
              <NextStatusAction order={order} statusIndex={statusIndex} onAdvance={advance} busy={changingStatus} primaryColor={primaryColor} />
              <DetailSections order={order} name={name} flavours={flavours} delivDate={delivDate} />
              <Section title="History">
                <AuditTrail orderId={order.id} apiClient={apiClient} refresh={auditRefresh} />
              </Section>
            </>
        }
      </div>
      {markingReady && (
        <MarkReadySheet order={order} apiClient={apiClient} primaryColor={primaryColor}
          busy={changingStatus} error={readyErr}
          onConfirm={confirmMarkReady} onCancel={() => { if (!changingStatus) setMarkingReady(false); }} />
      )}
    </div>
  );
}

// The requirement as a chip. Text-first — the label always reads, colour only speeds
// up scanning — so this survives a greyscale print and a colour-blind reader. See
// dietary.js for why there is no veg green dot.
function DietChip({ req, small = false }) {
  const t = dietTone(req.kind);
  return (
    <span style={{
      display: 'inline-block', padding: small ? '1px 6px' : '3px 9px',
      borderRadius: 6, fontSize: small ? 10 : 11, fontWeight: 800, letterSpacing: 0.2,
      background: t.bg, color: t.fg, border: `1px solid ${t.border}`, whiteSpace: 'nowrap',
    }}>{req.label}</span>
  );
}

function DietChips({ reqs, small = false }) {
  if (!reqs?.length) return null;
  return (
    <span style={{ display: 'inline-flex', gap: 4, flexWrap: 'wrap', alignItems: 'center' }}>
      {reqs.map(r => <DietChip key={r.key} req={r} small={small} />)}
    </span>
  );
}

function DetailSections({ order, name, flavours, delivDate }) {
  const customer = order.customers;
  return (
    <>
      <Section title="Customer">
        <InfoRow label="Name"  value={name} />
        <InfoRow label="Phone" value={customer?.phone} />
        <InfoRow label="Email" value={customer?.email} />
      </Section>

      <Section title="Order">
        {order.weight_kg && <InfoRow label="Weight" value={`${order.weight_kg} kg`} />}
        {flavours.length > 0 && <InfoRow label="Flavours" value={flavours.join(', ')} />}
        {order.dietary_requirements?.length > 0 && (
          <InfoRow label="Dietary" value={<DietChips reqs={order.dietary_requirements} />} />
        )}
        {order.special_instructions && <InfoRow label="Notes" value={order.special_instructions} />}
      </Section>

      <Section title="Delivery">
        <InfoRow label="Mode"    value={order.delivery_mode === 'home_delivery' ? 'Home Delivery' : 'Pickup'} />
        <InfoRow label="Date"    value={delivDate} />
        <InfoRow label="Time"    value={order.delivery_time} />
        <InfoRow label="Address" value={order.delivery_address} />
      </Section>

      <div style={{ marginTop: 4, fontSize: 11, color: '#ccc', fontFamily: 'monospace' }}>
        #{order.id.toUpperCase()} · placed {fmt(order.created_at)}
      </div>
    </>
  );
}

function Section({ title, children }) {
  const items = Array.isArray(children) ? children.filter(Boolean) : children ? [children] : [];
  if (items.length === 0) return null;
  return (
    <div style={{ marginBottom: 28 }}>
      <div style={{ fontSize: 11, fontWeight: 800, color: '#bbb', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 14, borderBottom: '1px solid #F0EDE8', paddingBottom: 8 }}>
        {title}
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {items}
      </div>
    </div>
  );
}

// ── List pane ─────────────────────────────────────────────────────────────────

function OrderList({ orders, loading, error, filter, onFilter, onSelect, selected, primaryColor, isMobile, statusIndex = DEFAULT_STATUS_INDEX }) {
  const orderedKeys = statusIndex.ordered.map(s => s.key);
  const counts  = orderedKeys.reduce((a, s) => ({ ...a, [s]: orders.filter(o => o.status === s).length }), {});
  const visible = filter === 'all' ? orders : orders.filter(o => o.status === filter);

  return (
    <div style={{
      width: isMobile ? '100%' : 320, flexShrink: 0,
      borderRight: isMobile ? 'none' : '1.5px solid #E8E4DC',
      background: '#fff', display: 'flex', flexDirection: 'column',
    }}>
      {/* Filter chips */}
      <div style={{ padding: '10px 14px', borderBottom: '1px solid #F0EDE8', display: 'flex', gap: 6, overflowX: 'auto', flexShrink: 0 }}>
        {[{ key: 'all', label: 'All', count: orders.length },
          ...orderedKeys.filter(s => counts[s] > 0).map(s => ({ key: s, label: statusLabel(statusIndex, s), count: counts[s] }))
        ].map(({ key, label, count }) => {
          const active = filter === key;
          return (
            <button key={key} onClick={() => onFilter(key)} style={{
              padding: '5px 12px', borderRadius: 20, border: 'none',
              fontSize: 11, fontWeight: 700, cursor: 'pointer', flexShrink: 0,
              fontFamily: 'inherit',
              background: active ? primaryColor : '#F0EDE8',
              color: active ? '#fff' : '#777',
            }}>
              {label} ({count})
            </button>
          );
        })}
      </div>

      {/* List */}
      <div style={{ flex: 1, overflowY: 'auto' }}>
        {loading && <Empty>Loading…</Empty>}
        {!loading && error && <Empty color="#e53935">{error}</Empty>}
        {!loading && !error && visible.length === 0 && <Empty>No orders yet.</Empty>}

        {!loading && visible.map(order => {
          const c     = order.customers;
          const name  = c ? `${c.first_name ?? ''} ${c.last_name ?? ''}`.trim() : 'Unknown';
          const isSelected = selected?.id === order.id;
          const flavours = (order.flavours ?? []).map(f => f.name ?? f.flavour).filter(Boolean);

          return (
            <div key={order.id} onClick={() => onSelect(order)} style={{
              padding: '14px 16px', cursor: 'pointer', borderBottom: '1px solid #F8F6F2',
              background: isSelected ? '#FAF7F4' : '#fff',
              borderLeft: isSelected ? `3px solid ${primaryColor}` : '3px solid transparent',
              transition: 'background 0.1s',
              display: 'flex', gap: 12, alignItems: 'center',
            }}>
              {/* Thumbnail */}
              <div style={{
                width: 44, height: 44, borderRadius: 10, flexShrink: 0,
                background: '#F0EDE8', overflow: 'hidden',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                border: '1px solid #E8E4DC',
              }}>
                {order.design_thumbnail_url
                  ? <img src={order.design_thumbnail_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  : <span style={{ color: '#ccc' }}><PhotoGlyph /></span>
                }
              </div>

              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 6, marginBottom: 4 }}>
                  <span style={{ fontSize: 13, fontWeight: 700, color: '#1a1a1a', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{name}</span>
                  <StatusBadge status={order.status} statusIndex={statusIndex} />
                </div>
                <div style={{ fontSize: 11, color: '#aaa', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {[fmt(order.delivery_date), flavours[0]].filter(Boolean).join(' · ') || fmt(order.created_at)}
                </div>
                {/* Its own line rather than appended to the subtitle above: that line
                    ellipsises, and a long flavour name would push the requirement off
                    the end of exactly the row where a baker is scanning for it. */}
                {order.dietary_requirements?.length > 0 && (
                  <div style={{ marginTop: 4 }}>
                    <DietChips reqs={order.dietary_requirements} small />
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Root ──────────────────────────────────────────────────────────────────────

export default function OrdersPanel({ open, onClose, onBack, onEditDesign, onNewOrder = null, apiClient, primaryColor = '#1a1a1a', externalFilter = null, homeDeliveryEnabled = false, initialOrderId = null, bakerSlug = null, initialView = 'list', bakerTimezone = null, onNewOrderForDate = null }) {
  const isMobile = useIsMobile();
  const [orders, setOrders]     = useState([]);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState(null);
  const [filter, setFilter]     = useState('all');
  const [selected, setSelected] = useState(null);
  const [statusIndex, setStatusIndex] = useState(DEFAULT_STATUS_INDEX);

  // The calendar is a VIEW of orders, not a separate destination: same panel, same
  // data, same filter path. It only exists when the host wired the counts endpoint.
  const hasCalendar = typeof apiClient?.fetchOrdersCalendar === 'function';
  const [view, setView] = useState(initialView === 'calendar' && hasCalendar ? 'calendar' : 'list');

  // A day picked in the calendar filters the list exactly the way the Dashboard's
  // "due today" card does. Held here so `externalFilter` (the host's) stays a pure
  // prop — `activeFilter` is the ONE filter authority the fetch and banner read.
  const [dateFilter, setDateFilter] = useState(null);
  const activeFilter = dateFilter ?? externalFilter;

  // Re-entering the panel from the rail's Calendar item must land on the calendar
  // even if the panel was last closed on the list (and vice versa).
  // The panel isn't unmounted when closed, so `selected` survives — clear it here or a
  // stale order detail would still own the mobile top bar when the calendar opens.
  useEffect(() => {
    if (!open) return;
    setView(initialView === 'calendar' && hasCalendar ? 'calendar' : 'list');
    setDateFilter(null);
    setSelected(null);
  }, [open, initialView]);

  // Pull the lifecycle from the DB when the host exposes it; otherwise the built-in
  // fallback (DEFAULT_STATUSES) keeps the panel working. The table is authoritative
  // when wired — core no longer owns the canonical status list.
  useEffect(() => {
    if (!open || !apiClient?.fetchOrderStatuses) return;
    apiClient.fetchOrderStatuses()
      .then(list => { if (Array.isArray(list) && list.length) setStatusIndex(buildStatusIndex(list)); })
      .catch(() => {});
  }, [open]);

  useEffect(() => {
    if (!open || view !== 'list') return;
    setLoading(true);
    setError(null);
    setSelected(null);
    const params = activeFilter?.params ?? {};
    apiClient.fetchOrders(params)
      .then(data => {
        const list = Array.isArray(data) ? data : [];
        setOrders(list);
        if (initialOrderId) {
          const match = list.find(o => o.id === initialOrderId);
          if (match) { setSelected(match); return; }
        }
        if (list.length && !isMobile) setSelected(list[0]);
      })
      .catch(err => setError(err.message ?? 'Failed to load orders'))
      .finally(() => setLoading(false));
  }, [open, view, activeFilter]);

  async function handleStatusChange(orderId, newStatus) {
    await apiClient.updateOrderStatus(orderId, newStatus);
    setOrders(os => os.map(o => o.id === orderId ? { ...o, status: newStatus } : o));
    setSelected(s => s?.id === orderId ? { ...s, status: newStatus } : s);
  }

  if (!open) return null;

  // Mobile: show list OR detail (not both)
  const showDetail = isMobile ? !!selected : true;
  const showList   = isMobile ? !selected  : true;

  const topBarTitle = isMobile && selected ? 'Order Details' : 'Orders';

  return (
    <>
      <style>{`
        @keyframes slideInRight { from { transform: translateX(100%) } to { transform: translateX(0) } }
      `}</style>

      <div style={{
        position: 'fixed', top: 0, right: 0, bottom: 0,
        left: isMobile ? 0 : 76,
        zIndex: 300,
        display: 'flex', flexDirection: 'column',
        animation: 'slideInRight 0.28s cubic-bezier(0.32,0.72,0,1)',
        fontFamily: "'Quicksand', sans-serif",
        background: '#F7F5F0',
        boxShadow: '-4px 0 24px rgba(0,0,0,0.1)',
      }}>
        {/* Top bar */}
        <div style={{
          height: 56, padding: '0 20px', background: '#fff',
          borderBottom: '1.5px solid #E8E4DC', flexShrink: 0,
          display: 'flex', alignItems: 'center', gap: 14,
        }}>
          <button onClick={isMobile && selected ? () => setSelected(null) : (onBack ?? onClose)} style={closeBtn}>
            <ArrowLeftIcon />
          </button>
          <span style={{ fontSize: 16, fontWeight: 800, color: '#1a1a1a' }}>{topBarTitle}</span>

          {/* List | Calendar — the calendar is a view of the same orders, so it lives
              here rather than being a separate destination. */}
          {hasCalendar && !selected ? (
            <div style={{
              display: 'flex', gap: 2, padding: 2, borderRadius: 10,
              background: '#F2F0EB', border: '1.5px solid #E8E4DC', flexShrink: 0,
            }}>
              {[{ id: 'list', label: 'List' }, { id: 'calendar', label: 'Calendar' }].map(v => (
                <button key={v.id}
                  onClick={() => { setView(v.id); if (v.id === 'calendar') { setDateFilter(null); setSelected(null); } }}
                  style={{
                    border: 'none', borderRadius: 8, cursor: 'pointer', fontFamily: 'inherit',
                    padding: isMobile ? '5px 10px' : '5px 14px', fontSize: 12, fontWeight: 800,
                    background: view === v.id ? '#fff' : 'transparent',
                    color:      view === v.id ? '#1a1a1a' : '#8a8a8a',
                    boxShadow:  view === v.id ? '0 1px 3px rgba(0,0,0,0.10)' : 'none',
                  }}>
                  {v.label}
                </button>
              ))}
            </div>
          ) : null}

          <span style={{ flex: 1 }} />

          {onNewOrder && (!isMobile || !selected) && (
            <button onClick={onNewOrder} style={{
              display: 'flex', alignItems: 'center', gap: 5,
              background: primaryColor, color: '#fff', border: 'none',
              borderRadius: 10, padding: '8px 14px', cursor: 'pointer',
              fontFamily: 'inherit', fontSize: 13, fontWeight: 800,
            }}>
              <span style={{ fontSize: 16, lineHeight: 1 }}>+</span> New Order
            </button>
          )}
          {view === 'list' && (!isMobile || !selected) && (
            <span style={{ fontSize: 13, color: '#bbb' }}>{orders.length} total</span>
          )}
          {onBack && (
            <button onClick={onClose} style={closeBtn} title="Home">
              <HomeIcon />
            </button>
          )}
        </div>

        {/* Filter banner — one banner for both the host's filter and a day picked in
            the calendar. Clearing a calendar day returns to the calendar it came from;
            clearing the host's filter closes the panel, as it always did. */}
        {activeFilter && view === 'list' && !selected && (
          <div style={{
            padding: '8px 20px', background: '#FEF9C3', borderBottom: '1px solid #FCD34D',
            display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0,
          }}>
            <span style={{ fontSize: 12, fontWeight: 700, color: '#92400E', flex: 1 }}>
              {activeFilter.label}
            </span>
            <button
              onClick={dateFilter ? () => { setDateFilter(null); setView('calendar'); } : onClose}
              style={{
                fontSize: 11, fontWeight: 700, color: '#92400E', background: 'none',
                border: '1px solid #FCD34D', borderRadius: 6, padding: '2px 8px',
                cursor: 'pointer', fontFamily: 'inherit',
              }}>{dateFilter ? '← Back to calendar' : '✕ Clear'}</button>
          </div>
        )}

        {/* Body */}
        <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
          {view === 'calendar' && (
            <OrdersCalendar
              apiClient={apiClient}
              statusIndex={statusIndex}
              isMobile={isMobile}
              primaryColor={primaryColor}
              timezone={bakerTimezone}
              onPickDate={date => {
                setDateFilter({ params: { delivery_date: date }, label: `Orders due ${fmtDateOnly(date)}` });
                setView('list');
              }}
              onCreateForDate={onNewOrderForDate ?? null}
            />
          )}

          {view === 'list' && showList && (
            <OrderList
              orders={orders}
              loading={loading}
              error={error}
              filter={filter}
              onFilter={setFilter}
              onSelect={setSelected}
              selected={selected}
              primaryColor={primaryColor}
              isMobile={isMobile}
              statusIndex={statusIndex}
            />
          )}

          {/* Detail pane */}
          {view === 'list' && showDetail && (
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
              {selected
                ? <OrderDetail
                    key={selected.id}
                    order={selected}
                    onEditDesign={(order, opts) => { onClose(); onEditDesign(order, opts); }}
                    onStatusChange={handleStatusChange}
                    onOrderEdited={(updated) => {
                      setOrders(os => os.map(o => o.id === updated.id ? { ...o, ...updated } : o));
                      setSelected(s => s?.id === updated.id ? { ...s, ...updated } : s);
                    }}
                    apiClient={apiClient}
                    primaryColor={primaryColor}
                    isMobile={isMobile}
                    homeDeliveryEnabled={homeDeliveryEnabled}
                    bakerSlug={bakerSlug}
                    statusIndex={statusIndex}
                  />
                : <Empty>Select an order to view details.</Empty>
              }
            </div>
          )}
        </div>
      </div>
    </>
  );
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function Empty({ children, color = '#bbb' }) {
  return <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color, fontSize: 14, padding: 40, textAlign: 'center' }}>{children}</div>;
}

// Reached steps render ink-black, unreached stay white/grey — a clean monochrome
// stepper (no per-status colours, no red).
const INK = '#1a1a1a';

// "Cancel order" text link — shared by the mobile action area and the status
// stepper so they stay identical.
function CancelOrderLink({ onClick, disabled }) {
  return (
    <button onClick={onClick} disabled={disabled} style={{
      background: 'none', border: 'none', padding: 0,
      fontSize: 12, color: '#888', fontFamily: 'inherit', fontWeight: 600,
      textDecoration: 'underline', textUnderlineOffset: 2,
      cursor: disabled ? 'default' : 'pointer', opacity: disabled ? 0.5 : 1,
    }}>Cancel order</button>
  );
}

// `hideCancel` lets a caller (mobile OrderDetail) lift the Cancel action into its
// own button row above the stepper, so the stepper renders the timeline only.
function StatusProgress({ status, onChange, disabled, readOnly = false, hideCancel = false, statusIndex = DEFAULT_STATUS_INDEX }) {
  const isMobile       = useIsMobile();
  const flowSteps      = statusIndex.flowSteps;
  const isClosedStatus = isClosed(statusIndex, status);   // cancelled / declined / expired
  const currentIdx     = flowSteps.findIndex(s => s.key === status);

  const closedBanner = (
    <div style={{
      marginBottom: 20, padding: '12px 16px', borderRadius: 12,
      background: '#F3F2EF', border: '1.5px solid #E0DDD8',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, fontWeight: 700, color: INK }}>
        <span style={{ fontSize: 18 }}>✕</span> Order {statusLabel(statusIndex, status)}
      </div>
      {!readOnly && flowSteps.length > 0 && (
        <button onClick={() => onChange(flowSteps[0].key)} disabled={disabled} style={{
          fontSize: 11, fontWeight: 700, color: INK, background: 'none',
          border: '1.5px solid #E0DDD8', borderRadius: 8, padding: '4px 10px',
          cursor: 'pointer', fontFamily: 'inherit', opacity: disabled ? 0.5 : 1,
        }}>Reopen</button>
      )}
    </div>
  );

  if (isClosedStatus) return closedBanner;

  // ── Mobile: vertical stepper ────────────────────────────────────────────────
  if (isMobile) {
    return (
      <div style={{ marginBottom: 20 }}>
        {flowSteps.map((step, i) => {
          const done     = i < currentIdx;
          const active   = i === currentIdx;
          const isLast   = i === flowSteps.length - 1;
          const reached  = done || active;
          const dotColor = reached ? INK : '#d1d5db';
          const canClick = !readOnly && !disabled && !active;

          return (
            <div
              key={step.key}
              onClick={() => canClick && onChange(step.key)}
              style={{
                display: 'flex', gap: 16,
                cursor: canClick ? 'pointer' : 'default',
                minHeight: isLast ? 32 : 0,
              }}
            >
              {/* Left: dot + vertical connector */}
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: 32, flexShrink: 0 }}>
                <div style={{
                  width: 32, height: 32, borderRadius: '50%', flexShrink: 0,
                  background: reached ? INK : '#fff',
                  border: `2.5px solid ${dotColor}`,
                  color: reached ? '#fff' : '#bbb',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 12, fontWeight: 700,
                  transition: 'all 0.2s',
                  boxShadow: active ? '0 0 0 4px rgba(26,26,26,0.12)' : 'none',
                }}>
                  {done
                    ? <svg width="13" height="13" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="2,6 5,9 10,3" /></svg>
                    : i + 1}
                </div>
                {!isLast && (
                  <div style={{
                    width: 2, flex: 1, minHeight: 20,
                    background: done ? INK : '#E8E4DC',
                    margin: '3px 0', transition: 'background 0.3s',
                  }} />
                )}
              </div>

              {/* Right: label */}
              <div style={{
                flex: 1, display: 'flex', alignItems: 'center',
                paddingBottom: isLast ? 0 : 20,
              }}>
                <span style={{
                  fontSize: 15, fontWeight: active ? 700 : 500,
                  color: reached ? INK : '#bbb',
                  transition: 'color 0.2s',
                }}>{step.label}</span>
              </div>
            </div>
          );
        })}

        {!readOnly && !hideCancel && !isTerminal(statusIndex, status) && (
          <div style={{ marginTop: 8 }}>
            <CancelOrderLink onClick={() => onChange('cancelled')} disabled={disabled} />
          </div>
        )}
      </div>
    );
  }

  // ── Desktop: horizontal stepper ─────────────────────────────────────────────
  const dotSize = 30;
  const connectorMarginTop = Math.round((dotSize - 3) / 2);

  return (
    <div style={{ marginBottom: 20 }}>
      <div style={{ display: 'flex', alignItems: 'flex-start' }}>
        {flowSteps.map((step, i) => {
          const done     = i < currentIdx;
          const active   = i === currentIdx;
          const reached  = done || active;
          const dotColor = reached ? INK : '#d1d5db';
          const canClick = !readOnly && !disabled && !active;

          return (
            <Fragment key={step.key}>
              {i > 0 && (
                <div style={{
                  flex: 1, height: 3, borderRadius: 2,
                  marginTop: connectorMarginTop,
                  background: reached ? INK : '#E8E4DC',
                  transition: 'background 0.3s',
                }} />
              )}
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5 }}>
                <button
                  onClick={() => canClick && onChange(step.key)}
                  disabled={!canClick}
                  title={step.label}
                  style={{
                    width: dotSize, height: dotSize, borderRadius: '50%', flexShrink: 0,
                    background: reached ? INK : '#fff',
                    border: `2.5px solid ${dotColor}`,
                    color: reached ? '#fff' : '#bbb',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    cursor: canClick ? 'pointer' : 'default',
                    fontFamily: 'inherit', fontSize: 11, fontWeight: 700,
                    transition: 'all 0.2s',
                    boxShadow: active ? '0 0 0 4px rgba(26,26,26,0.12)' : 'none',
                    outline: 'none',
                  }}
                >
                  {done
                    ? <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="2,6 5,9 10,3" /></svg>
                    : i + 1}
                </button>
                <span style={{
                  fontSize: 9, fontWeight: 700, textAlign: 'center',
                  color: reached ? INK : '#aaa',
                  lineHeight: 1.2, whiteSpace: 'nowrap',
                }}>{step.label}</span>
              </div>
            </Fragment>
          );
        })}
      </div>

      {!readOnly && !isTerminal(statusIndex, status) && (
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 6 }}>
          <button onClick={() => onChange('cancelled')} disabled={disabled} style={{
            background: 'none', border: 'none', padding: 0,
            fontSize: 11, color: '#888', fontFamily: 'inherit', fontWeight: 600,
            textDecoration: 'underline', textUnderlineOffset: 2,
            cursor: disabled ? 'default' : 'pointer', opacity: disabled ? 0.5 : 1,
          }}>Cancel order</button>
        </div>
      )}
    </div>
  );
}


function PencilIcon({ size = 15 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
    </svg>
  );
}

const closeBtn = {
  width: 32, height: 32, borderRadius: 8,
  border: '1.5px solid #E8E4DC', background: '#F7F5F0',
  cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
  fontSize: 13, color: '#666', flexShrink: 0,
};

function ArrowLeftIcon() {
  return (
    <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M19 12H5M12 5l-7 7 7 7" />
    </svg>
  );
}

function HomeIcon() {
  return (
    <svg width={15} height={15} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 9.5L12 3l9 6.5V20a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V9.5z" />
      <path d="M9 21V12h6v9" />
    </svg>
  );
}
