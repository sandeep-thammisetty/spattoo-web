// Standard ("Honeybear-style") typography — one clean geometric sans for headings + body.
const SANS = "'Montserrat', system-ui, -apple-system, sans-serif";

// ── Storefront template registry ────────────────────────────────────────────────────────────────
// A template is DATA over the ONE shared renderer (CustomerStorefront) + the ONE shared customiser
// (ThemePreview). Adding a template is a config object here — never a forked layout or a per-theme
// branch. See docs/TEMPLATE_CONFIG.md for the full shape. Each template is:
//
//   {
//     key, label,
//     tokens:   <renderer config> — typography, neutral inks, surface colour, spacing, the HERO
//               (`hero.type` selects a HERO_RENDERERS entry + its layout knobs), and palette hints
//               (`cake`, `pageBgMode`, header colours). Passed to buildPalette() + styles().
//     defaults: { primary, accent, ctaColor } — the designed starting palette the CUSTOMISER seeds
//               into the pickers when the template is selected. The storefront always RENDERS from
//               the pickers (colours derive from them in buildPalette), so every colour stays editable.
//     controls: [...] — which customiser controls to show, in order (→ DEFAULT_CONTROLS if omitted).
//   }
//
// spotlight (labelled "Standard") reproduces the original look; its key is unchanged so existing
// bakers need no data migration.

const SPOTLIGHT_TOKENS = {
  font:         SANS,                                  // body
  serif:        SANS,                                  // headings (clean sans)
  brandFont:    "'Pacifico', cursive",                 // the bakery name — thick, curvy script
  pageBg:       '#FFFFFF',
  heading:      '#241A1E',
  text:         '#3A2E32',
  muted:        '#8B7B80',
  cardBorder:   '#ECE5DE',
  shadow:       '0 12px 30px rgba(60,40,45,0.08)',
  contentWidth: 600,
  // The dark hero/footer "ink" is mixed FROM the baker's primary; inkMix retunes that mix as data.
  inkMix:       { with: '#3a363a', amount: 0.74 },
  // HERO: the signature centred cake on a brand-tinted band with a wavy bottom (split on wide).
  hero:         { type: 'centered-cake' },
};

const AURORA_TOKENS = {
  font:         SANS,                                  // body — modern geometric sans
  serif:        SANS,                                  // headings also sans (heavy weight set in styles)
  brandFont:    SANS,                                  // modern wordmark (not the script) to match the gradient
  // Top-flush header: no white bar — the header + util strip are transparent so the cream/gradient
  // shows from pixel 0. (spotlight leaves these unset → its opaque light header.)
  headerBg:         'transparent',
  headerBorderColor:'transparent',
  utilbarBg:        'transparent',
  heading:      '#3A281C',                             // body-section neutrals (below the hero)
  text:         '#5A4636',
  muted:        '#9C8A79',
  cardBorder:   '#EFE4D6',
  shadow:       '0 14px 34px rgba(80,50,30,0.10)',
  contentWidth: 600,
  inkMix:       { with: '#2C1D13', amount: 0.70 },     // warm dark ink for footer/sections
  // HERO: `type` selects the renderer from HERO_RENDERERS. The remaining keys are LAYOUT knobs for
  // this hero, per breakpoint as [mobile, tablet, desktop]: they keep the message clear of the cake —
  // textWidth = the headline/CTA column; subMaxWidth caps the subtitle LEFT of the cake; cakeWidth +
  // cakeRight size and bleed the cake off the right; minHeight = hero height. Retune = data change.
  hero: {
    type:        'gradient-cake',
    textWidth:   ['66%', '56%', '54%'],
    subMaxWidth: [230, 300, 320],
    cakeWidth:   [360, 520, 620],
    cakeRight:   [-90, -120, -140],
    minHeight:   [440, 460, 540],
  },
  // Palette hints for the gradient hero — DERIVED from the pickers in buildPalette (moving a picker
  // moves the design): cake:'brand' → the 3D cake takes the primary colour; pageBgMode:'heroTop' →
  // the page/top surface = the gradient's derived light top tone.
  cake:        'brand',
  pageBgMode:  'heroTop',
};

// Which customiser controls a template exposes, in order. The customiser (ThemePreview) renders the
// left panel from this list; omit it → DEFAULT_CONTROLS (all). This is how a template hides
// irrelevant knobs (e.g. a photo-hero template would swap in a hero-photo uploader).
// ── Patisserie — the premium, hand-drawn theme ──────────────────────────────────────────────────
// Ink linework and soft watercolour washes on warm paper, instead of the flat colour every other
// theme uses. That medium IS the product here: a baker paying for the premium theme is buying the
// look of a hand-painted patisserie, and the storefront is the one page their customers judge them
// on before tasting anything.
//
// ⚠️ EVERY MARK IS OURS, DRAWN IN CODE. The brief arrived as a photograph of another bakery's brand
// illustration. Nothing from it is traced, embedded or redrawn — that artwork and its hand-lettered
// wordmark are a real company's identity, and imitating them closely enough to be recognised is
// passing off, not inspiration. What is taken is the STYLE LANGUAGE, which nobody owns: ink line +
// watercolour wash, blush/duck-egg/cherry, scalloped and doily edges, an arched shop window, and
// composition that leaves a lot of paper showing. Restraint is what reads as premium; density does
// not. The facade is SVG we author (heroes/Shopfront.jsx), so there is no image asset at all.
const PATISSERIE_TOKENS = {
  // Body. NOT the shared SANS: Montserrat is a geometric sans with even stroke weight, and beside
  // ink linework and a copperplate wordmark it was the one element still reading as a web app. Lora
  // has brush-drawn roots and real thick/thin, so the words match the drawing.
  font:      "'Lora', Georgia, serif",
  serif:     "'Cormorant Garamond', Georgia, serif",        // headings — high-contrast, unhurried
  // The wordmark. Pacifico (thick, rounded, one stroke width) is the wrong instrument for an
  // ink-line theme; Parisienne is a fine copperplate with real thick/thin. Registered in
  // spattoo-web's next/font — see shared/fonts.js for why a LIBRARY only names its fonts.
  brandFont: "'Parisienne', 'Cormorant Garamond', cursive",
  // The DRAWN face, for the primary button and the section eyebrows — the two places the page
  // speaks in its own voice rather than the baker's. Cormorant on the button was refined and
  // formal: it said "menu", not "hand-drawn", which is the one note this theme cannot afford to
  // miss on the thing a customer actually clicks. Marker contours on a SANS skeleton, so it reads
  // instantly at button size; a true handwriting face (Caveat) was tried and loses too much
  // legibility at 15px on a phone.
  handFont:  "'Shantell Sans', 'Trebuchet MS', cursive",
  // Warm paper, never #FFF: pure white makes a watercolour wash look like a sticker on a screen.
  pageBg:     '#FFFCF8',
  heading:    '#2E3A46',      // ink — a blue-black, the colour a dip pen actually leaves
  text:       '#4A5561',
  muted:      '#93A0AC',
  cardBorder: '#E7DFD8',
  // A wash, not a drop shadow: wide, faint and slightly warm, so cards sit ON paper rather than
  // float above a UI.
  shadow:     '0 14px 34px rgba(70,60,66,0.07)',
  contentWidth: 600,
  inkMix:     { with: '#2E3A46', amount: 0.72 },
  hero:       { type: 'shopfront' },
  // ── THE PAPER THE SHOP IS DRAWN ON ────────────────────────────────────────────────────────
  // Same idea as Ink and for the same reason: this theme is an illustration, and its background is
  // the sheet the illustration sits on rather than a colour behind a layout. The Shopfront drawing
  // takes `paper={s.page.background}`, so the facade, the awning and the window all re-tint with
  // the choice — nothing to wire, and nothing that can disagree with the page.
  //
  // Every option is light. A dark ground would not restyle this theme, it would leave a line
  // drawing with no paper under it — which is why this is a list and not a picker.
  //
  // Ivory is FIRST and is the current pageBg exactly, so a baker who has never touched this keeps
  // the shop they already published.
  grounds: [
    { key: 'ivory',  label: 'Ivory',  value: '#FFFCF8' },   // today's default
    { key: 'cream',  label: 'Cream',  value: '#FBF3E7' },
    { key: 'blush',  label: 'Blush',  value: '#FBEFEF' },
    { key: 'mint',   label: 'Mint',   value: '#EDF5F1' },
    { key: 'sky',    label: 'Sky',    value: '#EEF3F7' },
    { key: 'butter', label: 'Butter', value: '#FCF4DF' },
  ],
  // Bands end in scallops rather than the product's signature wave — the same edge as the awning
  // and the doily, so the motif carries down the page instead of stopping at the hero.
  edges:      'scallop',
  // The type is part of the drawing, not a preference: the copperplate wordmark and the brush-rooted
  // body are half of why this reads as hand-made. The font picker would swap all three for
  // Pacifico + a geometric sans and leave a premium theme looking like the standard one wearing a
  // shopfront. See `ownsType` in CustomerStorefront.
  ownsType:   true,
  // The 3D cake takes the baker's own primary — it is their cake in their shop window, which is the
  // entire point of the hero.
  cake:       'brand',
};

// ── Atelier — the severe one ────────────────────────────────────────────────────────────────────
// Bone, ink, one hairline. Built as the deliberate opposite of Patisserie, because a picker whose
// themes differ only in COLOUR is a picker of recolours and nobody pays for a recolour. Where that
// one is drawn, warm and curved, this is photographed, cold and straight: no illustration, no wave,
// no script — the expense is in the restraint and the size of the type.
//
// The wordmark is a heavy SANS in caps, wide-tracked, the way a fashion house sets its name — not a
// script. That single choice is most of the difference: script says handmade, caps say house.
const ATELIER_TOKENS = {
  font:      SANS,                                       // body — plain, small, quiet
  serif:     "'Cormorant Garamond', Georgia, serif",     // the big editorial headline
  brandFont: SANS,
  brandMark: 'caps',                                     // house mark, not a script wordmark
  // Bone rather than white. Pure #FFF under a black rule reads as an unstyled document; bone reads
  // as paper stock, which is the whole trick of an editorial page.
  pageBg:     '#F7F5F1',
  heading:    '#111111',
  text:       '#3A3A38',
  muted:      '#8E8E88',
  cardBorder: '#E2DFD8',
  // Almost no shadow. Editorial pages sit FLAT — a card that floats belongs to a dashboard.
  shadow:     '0 1px 0 rgba(17,17,17,0.06)',
  contentWidth: 600,
  inkMix:     { with: '#111111', amount: 0.86 },
  hero:       { type: 'atelier' },
  // Straight. The product's signature wave would be the one soft thing on a page selling severity.
  edges:      'rule',
  // Square corners and hairlines instead of rounded cards with shadows: rounded + shadowed reads
  // APP, square + hairline reads PRINT, and that distinction changes the page more than any colour.
  radius:     0,
  cardStyle:  'flat',
  // The gallery breaks out of the content column — images edge to edge, captions as print credits.
  gallery:    'bleed',
  // Left, not centred. Centred-everything is what a page looks like when nobody decided, and it is
  // the most template-ish thing about the storefront — no palette escapes it.
  align:      'left',
  // The hero IS the wordmark here, so the header does not repeat it.
  headerBrand: false,
  // The type IS the design here, exactly as in Patisserie — a font picker would undo it.
  ownsType:   true,
  cake:       'brand',
};

// ── INK ─────────────────────────────────────────────────────────────────────────────────────────
// Everything on the page is drawn in ink on paper: no photograph, no render, no rotating cake. That
// is the whole theme, and it is why it is called Ink.
//
// It exists because of a complaint that was correct — Spotlight, Aurora and Atelier are the same
// storefront in different clothes, and bakers can tell. Their tokens are radius, shadow, align,
// edges: every one of them a STYLE. The thing all three share is the 3D cake in the hero, so no
// amount of restyling around it makes them feel like different shops. This theme's hero is a
// DRAWING, which nothing else uses.
const INK_TOKENS = {
  font:      SANS,
  serif:     "'Cormorant Garamond', Georgia, serif",
  brandFont: "'Cormorant Garamond', Georgia, serif",
  brandMark: 'caps',
  // Ink on paper, warmer than Atelier's bone — this theme is drawn rather than printed, and a warm
  // ground is what makes a line drawing read as ink rather than as a diagram.
  pageBg:     '#EFE7DA',
  heading:    '#2E3A46',
  text:       '#4A5560',
  muted:      '#8C8578',
  cardBorder: '#DED3C2',
  shadow:     '0 1px 0 rgba(46,58,70,0.06)',
  contentWidth: 640,
  inkMix:     { with: '#2E3A46', amount: 0.82 },
  hero:       { type: 'ink' },
  edges:      'rule',
  radius:     0,
  cardStyle:  'flat',
  align:      'left',
  // The hero IS the wordmark — the same rule Atelier settled. A logo in the header and the name
  // spelled out in the hero is the same identity twice on one screen.
  headerBrand: false,
  // Cormorant 600, widely tracked, chosen over the same face at 700 and a light Montserrat: a
  // high-contrast serif has hairlines close to the DRAWING'S own line, so the mark and the
  // illustration read as one hand. 600 is also the lightest weight the host loads (spattoo-web
  // layout.tsx) — asking for 300 gives a faux-light that looks right only where the font is
  // installed locally.
  ownsType:   true,
  // No 3D cake anywhere in this theme.
  cake:       'brand',
  // ── THE PAPER THE INK SITS ON ─────────────────────────────────────────────────────────────
  // A baker picks the ground from THIS LIST and nothing else. Not a free colour picker, for the
  // same reason this theme has no font picker: the background here is not decoration, it is the
  // paper — the wordmark, the body text and the DRAWING'S linework are all one fixed ink laid on
  // it. A dark ground would not restyle the page, it would erase it.
  //
  // A free picker is possible, but it is a different feature: every ink on the page would have to
  // be DERIVED from the chosen ground rather than fixed, and the result is a theme that can look
  // like anything, which is not what someone chooses Ink for.
  //
  // The list is also the validator. The renderer honours a stored ground only if it appears here,
  // so a value that arrives from an older theme, a hand-edited payload or a future edit to this
  // list degrades to the default instead of painting an unreadable shop.
  grounds: [
    { key: 'paper',  label: 'Paper',  value: '#EFE7DA' },   // the default — warm, and the one the drawing was drawn on
    { key: 'bone',   label: 'Bone',   value: '#F4F1EA' },
    { key: 'oat',    label: 'Oat',    value: '#E8DFCD' },
    { key: 'blush',  label: 'Blush',  value: '#F2E6E2' },
    { key: 'sage',   label: 'Sage',   value: '#E4E8DE' },
    { key: 'mist',   label: 'Mist',   value: '#E6EAEC' },
  ],
};

// Put the paper picker immediately after the colour pickers. Extracted the moment a second theme
// wanted it: the same splice written twice is the copy that drifts, and "where does Paper go" is a
// rule about the panel, not a fact about a theme.
const withGroundControl = list => {
  const at = list.indexOf('brandColors');
  return at < 0 ? [...list, 'ground'] : [...list.slice(0, at + 1), 'ground', ...list.slice(at + 1)];
};

export const DEFAULT_CONTROLS = ['brandColors', 'hero', 'font', 'photo', 'text', 'sections', 'gallery', 'reviews'];

export const TEMPLATES = {
  spotlight: {
    key: 'spotlight', label: 'Standard', tokens: SPOTLIGHT_TOKENS,
    defaults: { primary: '#9FA28B', accent: '#A3AB9B', ctaColor: '#EAEBE5' },   // designed sage/green
    controls: DEFAULT_CONTROLS,
  },
  aurora: {
    key: 'aurora', label: 'Aurora', tokens: AURORA_TOKENS,
    defaults: { primary: '#5B3A29', accent: '#C8945B', ctaColor: '#3A281C' },   // chocolate/caramel + dark hero text
    controls: DEFAULT_CONTROLS,
  },
  atelier: {
    key: 'atelier', label: 'Atelier', tokens: ATELIER_TOKENS,
    // Ink, bone, and the baker's own accent as the ONE colour on the page. Deliberately not a
    // palette: the restraint is the product, and a baker who wants three colours wants a different
    // theme.
    defaults: { primary: '#1A1A18', accent: '#A8654B', ctaColor: '#F7F5F1' },
    controls: DEFAULT_CONTROLS.filter(c => c !== 'font'),
  },
  ink: {
    key: 'ink', label: 'Ink', tokens: INK_TOKENS,
    // The type IS the design here, as in Patisserie and Atelier — a font picker would undo it.
    controls: withGroundControl(DEFAULT_CONTROLS.filter(c => c !== 'font')),
    // ⚠️ PRIMARY IS A COLOUR, NOT THE INK — the correction to a mistake this theme shipped with, and
    // the same one Atelier made: primary was #2E3A46, the ink itself. buildPalette derives the whole
    // page from primary (`bandSoftA = lighten(primary, 0.66)` is the "Our story" band, the empty
    // gallery is `lighten(primary, .42)`), so setting it to the ink painted every surface slate-grey
    // on a warm paper page. The theme's identity is carried by its TOKENS — the paper, the ink type,
    // the drawing — never by this picker, which exists to tint the furniture.
    defaults: { primary: '#A8654B', accent: '#C9A98A', ctaColor: '#F7F2E9' },
  },
  patisserie: {
    key: 'patisserie', label: 'Patisserie', tokens: PATISSERIE_TOKENS,
    // Every control except `font` — the theme owns its typography (ownsType), so offering the picker
    // would be offering a knob that is wired to nothing.
    controls: withGroundControl(DEFAULT_CONTROLS.filter(c => c !== 'font')),
    // Blush facade, duck-egg trim, cherry for the CTA — the three colours that carry the style, and
    // all three stay editable: the facade, the awning and the hearts are painted FROM these pickers,
    // so a baker who wants a mint-green shop gets one rather than a picture they cannot change.
    // ⚠️ ctaColor is the LABEL colour, not the button fill (buildPalette: onCta = heroText =
    // opts.ctaColor). Cherry red here meant red TEXT on the pink button, which is what shipped and
    // read as a warning rather than an invitation. It is the drawing's ink now — near-black on
    // blush, which is what the rest of the theme does.
    defaults: { primary: '#E9B7C2', accent: '#A9CBD4', ctaColor: '#2E3A46' },
  },
};

// Resolve a baker's chosen template key to a built template. Unknown / missing → the baseline,
// so the storefront always renders.
export function resolveTemplate(key) {
  return (key && TEMPLATES[key]) || TEMPLATES.spotlight;
}
