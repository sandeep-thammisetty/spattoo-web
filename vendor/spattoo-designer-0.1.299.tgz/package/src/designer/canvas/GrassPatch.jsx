import { useMemo, useRef, useLayoutEffect } from 'react';
import * as THREE from 'three';
import { buildGrassTuft, grassSeats, GRASS_DEFAULTS } from '../geometry/grass.js';

// ── A field of piped grass on a surface ───────────────────────────────────────
// The canvas's FIRST instanced path. Everywhere else (ring shells, decoration rings) clones the
// source per position, which is right for a handful of pieces and wrong here: a dense top is ~3000
// tufts, and 3000 clones is 3000 meshes for the renderer to walk every frame.
//
// One InstancedMesh means one draw call over ~120 triangles of real geometry, however many tufts
// there are. That is the difference between grass being usable on a phone and not.
export default function GrassPatch({
  shape, topY, color = '#4caf3d',
  strands = GRASS_DEFAULTS.strands,
  height  = GRASS_DEFAULTS.height,
  spacing = GRASS_DEFAULTS.spacing,
  jitter  = GRASS_DEFAULTS.jitter,
  splay   = GRASS_DEFAULTS.splay,
  droop   = GRASS_DEFAULTS.droop,
  thickness = GRASS_DEFAULTS.thickness,
  lengthVary = GRASS_DEFAULTS.lengthVary,
  bandInner = null, hole = null, inset = 0.98, overhang = 0, seed = 7,
  onStats,
}) {
  const geo = useMemo(
    () => buildGrassTuft({ strands, height, thickness, splay, droop, lengthVary, seed }),
    [strands, height, thickness, splay, droop, lengthVary, seed],
  );
  const seats = useMemo(
    () => grassSeats({ shape, spacing, jitter, inset, seed: seed + 1, bandInner, hole, overhang }),
    [shape, spacing, jitter, inset, seed, bandInner, hole, overhang],
  );

  const ref = useRef(null);
  useLayoutEffect(() => {
    const mesh = ref.current;
    if (!mesh) return;
    const m = new THREE.Matrix4(), q = new THREE.Quaternion(), tip = new THREE.Quaternion();
    const up = new THREE.Vector3(0, 1, 0), axis = new THREE.Vector3();
    const pos = new THREE.Vector3(), scl = new THREE.Vector3();
    seats.forEach((s, i) => {
      // Yaw, and — only for a tuft at the rim — a tip OUTWARD so its blades drape over the side.
      // Tipping is wrong anywhere else: mid-surface it would lift a clump's blades off the cake on
      // one side and bury them on the other. At the edge there is nothing underneath to bury into,
      // which is exactly what makes the drape possible. grassSeats decides which seats qualify.
      q.setFromAxisAngle(up, s.yaw);
      if (s.lean) {
        // Rotating about (sin·out, 0, cos·out) × up tips +Y toward the outward direction: the axis
        // is horizontal and perpendicular to it, so the clump falls away from the cake, not along it.
        axis.set(Math.cos(s.out), 0, -Math.sin(s.out));
        tip.setFromAxisAngle(axis, s.lean);
        q.premultiply(tip);
      }
      pos.set(s.x, topY, s.z);
      scl.setScalar(s.scale);
      mesh.setMatrixAt(i, m.compose(pos, q, scl));
    });
    mesh.instanceMatrix.needsUpdate = true;
    mesh.computeBoundingSphere();
  }, [seats, topY]);

  useLayoutEffect(() => { onStats?.({ tufts: seats.length, blades: seats.length * strands }); },
    [seats, strands, onStats]);

  if (!seats.length) return null;
  return (
    <instancedMesh ref={ref} args={[geo, undefined, seats.length]} castShadow receiveShadow>
      {/* Flat-ish and slightly waxy, like coloured buttercream — a shiny blade reads as plastic. */}
      <meshStandardMaterial color={color} roughness={0.72} metalness={0} />
    </instancedMesh>
  );
}
